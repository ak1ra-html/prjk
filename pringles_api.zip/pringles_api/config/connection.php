<?php
// Izinkan akses dari aplikasi luar (Flutter) - CORS Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Konfigurasi Database
$host = "localhost";
$user = "root"; // Default username XAMPP
$pass = "";     // Default password XAMPP (kosong)
$db   = "pringles_store";

// Membuat koneksi
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    // Jika gagal, hentikan program dan kirim pesan error format JSON
    die(json_encode([
        "status" => "error",
        "message" => "Koneksi database gagal: " . $conn->connect_error
    ]));
}

// Set charset ke utf8mb4 agar mendukung karakter khusus
$conn->set_charset("utf8mb4");

// Catatan: File ini tidak perlu menampilkan "Koneksi Berhasil" (echo) 
// karena akan merusak format JSON saat merespon API ke Flutter nantinya.
?>